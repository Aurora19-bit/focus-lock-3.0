package com.vidhya.focuslock

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.sin

data class AppInfoItem(
    val appName: String,
    val packageName: String,
    val icon: Drawable?
)

class MainActivity : AppCompatActivity() {
    private lateinit var sessionManager: SessionManager

    // Top Header
    private lateinit var tvVitalityBadge: TextView
    private lateinit var btnAmbientSound: TextView
    private lateinit var btnTimeOfDay: TextView
    private var timeOfDayIndex = 0
    private val timeOfDayModes = listOf("🌌 Night", "☀️ Day", "🌅 Sunset")

    // Anti-distraction Quotes
    private lateinit var tvBannerQuote: TextView
    private lateinit var btnNextQuote: TextView
    private var currentQuoteIndex = 0
    private val quotesList = listOf(
        "While you scroll mindlessly, your true ambitions are dying in silence.",
        "That notification was engineered by psychologists to steal your potential.",
        "Discipline is choosing between what you want now and what you want most.",
        "The ocean does not rush, yet everything is accomplished in deep stillness.",
        "Deep focus is a superpower in an age of constant cheap dopamine.",
        "Surface only when the mission is accomplished. Stay in the deep abyss."
    )

    // Bottom Navigation Tabs
    private lateinit var tabBtnTimer: LinearLayout
    private lateinit var tabBtnAquarium: LinearLayout
    private lateinit var tabBtnStats: LinearLayout
    private lateinit var tabBtnProfile: LinearLayout

    // Tab Views
    private lateinit var viewTimerTab: View
    private lateinit var viewAquariumTab: View
    private lateinit var viewStatsTab: View
    private lateinit var viewProfileTab: View

    // Timer Sub-sections
    private lateinit var btnSubTabClock: TextView
    private lateinit var btnSubTabBlocklist: TextView
    private lateinit var layoutClockSection: View
    private lateinit var layoutBlocklistSection: View

    // Mode Switcher
    private lateinit var btnModeStrict: TextView
    private lateinit var btnModeFreeFlow: TextView
    private var isStrictLockout = true

    // Center Display
    private lateinit var tvSelectedOrganismVisual: TextView
    private lateinit var tvCreatureStageBadge: TextView
    private lateinit var tvOrganismName: TextView
    private lateinit var tvTimerCountdown: TextView
    private lateinit var tvDepthIndicator: TextView
    private lateinit var btnStartDive: Button
    private lateinit var layoutCenterCreatureCard: View

    // Duration Chips
    private var selectedFocusMinutes = 25
    private lateinit var chips: List<TextView>

    // Organisms
    private var selectedOrganism = "whale"

    // Vitality Points & Decorators
    private var vitalityPoints = 480
    private var unlockedPearl = false
    private var unlockedAnemone = false
    private var unlockedVent = false

    // Ambient Sound Synthesis
    private var currentSoundTrack = 0
    private var synthTrack: AudioTrack? = null
    private var audioRunning = false
    private val soundNames = listOf("🔊 Waves", "🫧 Bubbles", "🌌 Drone", "🔇 Mute")

    // Apps & Blocklist Presets
    private lateinit var etSearchApps: EditText
    private lateinit var rvApps: RecyclerView
    private lateinit var tvAppsCountBadge: TextView
    private lateinit var btnSelectAll: Button
    private lateinit var btnClearAll: Button
    private var allAppsList = listOf<AppInfoItem>()
    private var filteredAppsList = listOf<AppInfoItem>()
    private lateinit var appAdapter: AppListAdapter

    // Stats
    private lateinit var tvDisciplineScore: TextView
    private lateinit var layoutWeeklyGraph: LinearLayout
    private lateinit var tvTotalFocusHours: TextView
    private lateinit var tvSessionsCompleted: TextView

    // Profile & Habits
    private lateinit var tvHabitScore: TextView
    private lateinit var rvLogs: RecyclerView
    private lateinit var btnClearLogs: Button
    private lateinit var tvEmptyLogs: TextView

    private var diveTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sessionManager = SessionManager(this)

        initViews()
        setupBottomNavigation()
        setupHeaderAndQuotes()
        setupTimerControls()
        setupOrganismCards()
        setupDurationChips()
        setupAquariumAndDecorators()
        setupHabits()
        setupAppsList()
        setupStats()
        setupLogs()
        checkPermissions()
    }

    override fun onResume() {
        super.onResume()
        updateTimerStateUI()
        refreshStatsUI()
        refreshLogsUI()
        startAquariumAnimations()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAmbientSound()
        diveTimer?.cancel()
    }

    private fun initViews() {
        tvVitalityBadge = findViewById(R.id.tvVitalityBadge)
        btnAmbientSound = findViewById(R.id.btnAmbientSound)
        btnTimeOfDay = findViewById(R.id.btnTimeOfDay)

        tvBannerQuote = findViewById(R.id.tvBannerQuote)
        btnNextQuote = findViewById(R.id.btnNextQuote)

        tabBtnTimer = findViewById(R.id.tabBtnTimer)
        tabBtnAquarium = findViewById(R.id.tabBtnAquarium)
        tabBtnStats = findViewById(R.id.tabBtnStats)
        tabBtnProfile = findViewById(R.id.tabBtnProfile)

        viewTimerTab = findViewById(R.id.viewTimerTab)
        viewAquariumTab = findViewById(R.id.viewAquariumTab)
        viewStatsTab = findViewById(R.id.viewStatsTab)
        viewProfileTab = findViewById(R.id.viewProfileTab)

        btnSubTabClock = findViewById(R.id.btnSubTabClock)
        btnSubTabBlocklist = findViewById(R.id.btnSubTabBlocklist)
        layoutClockSection = findViewById(R.id.layoutClockSection)
        layoutBlocklistSection = findViewById(R.id.layoutBlocklistSection)

        btnModeStrict = findViewById(R.id.btnModeStrict)
        btnModeFreeFlow = findViewById(R.id.btnModeFreeFlow)

        layoutCenterCreatureCard = findViewById(R.id.layoutCenterCreatureCard)
        tvSelectedOrganismVisual = findViewById(R.id.tvSelectedOrganismVisual)
        tvCreatureStageBadge = findViewById(R.id.tvCreatureStageBadge)
        tvOrganismName = findViewById(R.id.tvOrganismName)
        tvTimerCountdown = findViewById(R.id.tvTimerCountdown)
        tvDepthIndicator = findViewById(R.id.tvDepthIndicator)
        btnStartDive = findViewById(R.id.btnStartDive)

        etSearchApps = findViewById(R.id.etSearchApps)
        rvApps = findViewById(R.id.rvApps)
        tvAppsCountBadge = findViewById(R.id.tvAppsCountBadge)
        btnSelectAll = findViewById(R.id.btnSelectAll)
        btnClearAll = findViewById(R.id.btnClearAll)

        tvDisciplineScore = findViewById(R.id.tvDisciplineScore)
        layoutWeeklyGraph = findViewById(R.id.layoutWeeklyGraph)
        tvTotalFocusHours = findViewById(R.id.tvTotalFocusHours)
        tvSessionsCompleted = findViewById(R.id.tvSessionsCompleted)

        tvHabitScore = findViewById(R.id.tvHabitScore)
        rvLogs = findViewById(R.id.rvLogs)
        btnClearLogs = findViewById(R.id.btnClearLogs)
        tvEmptyLogs = findViewById(R.id.tvEmptyLogs)
    }

    private fun setupHeaderAndQuotes() {
        btnTimeOfDay.setOnClickListener {
            timeOfDayIndex = (timeOfDayIndex + 1) % timeOfDayModes.size
            btnTimeOfDay.text = timeOfDayModes[timeOfDayIndex]
            val bg = when (timeOfDayIndex) {
                1 -> 0xFF0F2B48.toInt() // Day
                2 -> 0xFF2D1B4E.toInt() // Sunset
                else -> 0xFF07192C.toInt() // Night
            }
            findViewById<View>(R.id.layoutTopHeader).setBackgroundColor(bg)
        }

        btnNextQuote.setOnClickListener {
            currentQuoteIndex = (currentQuoteIndex + 1) % quotesList.size
            tvBannerQuote.text = quotesList[currentQuoteIndex]
        }
    }

    private fun setupBottomNavigation() {
        fun switchTab(index: Int) {
            viewTimerTab.visibility = if (index == 0) View.VISIBLE else View.GONE
            viewAquariumTab.visibility = if (index == 1) View.VISIBLE else View.GONE
            viewStatsTab.visibility = if (index == 2) View.VISIBLE else View.GONE
            viewProfileTab.visibility = if (index == 3) View.VISIBLE else View.GONE

            tabBtnTimer.alpha = if (index == 0) 1.0f else 0.5f
            tabBtnAquarium.alpha = if (index == 1) 1.0f else 0.5f
            tabBtnStats.alpha = if (index == 2) 1.0f else 0.5f
            tabBtnProfile.alpha = if (index == 3) 1.0f else 0.5f

            if (index == 1) startAquariumAnimations()
            if (index == 2) refreshStatsUI()
            if (index == 3) refreshLogsUI()
        }

        tabBtnTimer.setOnClickListener { switchTab(0) }
        tabBtnAquarium.setOnClickListener { switchTab(1) }
        tabBtnStats.setOnClickListener { switchTab(2) }
        tabBtnProfile.setOnClickListener { switchTab(3) }
        switchTab(0)
    }

    private fun setupTimerControls() {
        btnSubTabClock.setOnClickListener {
            layoutClockSection.visibility = View.VISIBLE
            layoutBlocklistSection.visibility = View.GONE
            btnSubTabClock.setBackgroundResource(R.drawable.bg_pill)
            btnSubTabClock.setTextColor(0xFFFFFFFF.toInt())
            btnSubTabBlocklist.setBackgroundColor(0)
            btnSubTabBlocklist.setTextColor(0xFF94A3B8.toInt())
        }
        btnSubTabBlocklist.setOnClickListener {
            layoutClockSection.visibility = View.GONE
            layoutBlocklistSection.visibility = View.VISIBLE
            btnSubTabBlocklist.setBackgroundResource(R.drawable.bg_pill)
            btnSubTabBlocklist.setTextColor(0xFFFFFFFF.toInt())
            btnSubTabClock.setBackgroundColor(0)
            btnSubTabClock.setTextColor(0xFF94A3B8.toInt())
            loadAllApps()
        }

        btnModeStrict.setOnClickListener {
            isStrictLockout = true
            btnModeStrict.setBackgroundResource(R.drawable.bg_pill)
            btnModeStrict.setTextColor(0xFFFFFFFF.toInt())
            btnModeFreeFlow.setBackgroundColor(0)
            btnModeFreeFlow.setTextColor(0xFF94A3B8.toInt())
            Toast.makeText(this, "Strict Lockout: Distractions strictly locked", Toast.LENGTH_SHORT).show()
        }
        btnModeFreeFlow.setOnClickListener {
            isStrictLockout = false
            btnModeFreeFlow.setBackgroundResource(R.drawable.bg_pill)
            btnModeFreeFlow.setTextColor(0xFFFFFFFF.toInt())
            btnModeStrict.setBackgroundColor(0)
            btnModeStrict.setTextColor(0xFF94A3B8.toInt())
            Toast.makeText(this, "Free-Flow: Peaceful standby ocean tracker", Toast.LENGTH_SHORT).show()
        }

        btnAmbientSound.setOnClickListener {
            currentSoundTrack = (currentSoundTrack + 1) % soundNames.size
            btnAmbientSound.text = soundNames[currentSoundTrack]
            if (currentSoundTrack == 3) {
                stopAmbientSound()
            } else {
                startAmbientSound()
            }
        }

        layoutCenterCreatureCard.setOnClickListener {
            showCreatureLoreDialog(selectedOrganism)
        }

        btnStartDive.setOnClickListener {
            if (sessionManager.isSessionActive()) {
                sessionManager.recordDisableAttempt()
                val intent = Intent(this, MathPuzzleActivity::class.java)
                startActivity(intent)
            } else {
                startDiveSession(selectedFocusMinutes)
            }
        }
    }

    private fun showCreatureLoreDialog(organism: String) {
        val (name, depth, lore) = when (organism) {
            "dolphin" -> Triple("🐬 Oceanic Dolphin", "20m–40m Depth", "Playful apex echolocator. Swims swiftly in sunlight reef zones to protect deep focus flow states.")
            "jelly" -> Triple("🪼 Bioluminescent Jellyfish", "45m–90m Depth", "Phosphorescent abyss dweller. Pulses with soothing neon cyan light to calm distracting dopamine urges.")
            "turtle" -> Triple("🐢 Azure Sea Turtle", "25m–55m Depth", "Ancient coral reef navigator. Known for unwavering steady patience across miles of open sea.")
            "clownfish" -> Triple("🐠 Coral Clownfish", "10m–30m Depth", "Vibrant anemone dweller. Immunized against distraction stings through symbiotic reef discipline.")
            "seahorse" -> Triple("🪸 Golden Seahorse", "5m–15m Depth", "Anchors firmly to sea kelp during oceanic currents. Teaches rock-solid stillness and focus.")
            else -> Triple("🐋 Blue Whale Leviathan", "50m–250m Depth", "The sovereign giant of the deep abyss. Dives into the deepest trenches of productivity with massive stamina.")
        }

        AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage("Depth: $depth

$lore

Growth Stage: Stage 3 (Apex Marine Companion)
Vitality Bonus: +20 VP on dive completion.")
            .setPositiveButton("Close", null)
            .show()
    }

    private fun setupOrganismCards() {
        val whale = findViewById<View>(R.id.cardOrganismWhale)
        val dolphin = findViewById<View>(R.id.cardOrganismDolphin)
        val jelly = findViewById<View>(R.id.cardOrganismJelly)
        val turtle = findViewById<View>(R.id.cardOrganismTurtle)
        val clown = findViewById<View>(R.id.cardOrganismClownfish)
        val seahorse = findViewById<View>(R.id.cardOrganismSeahorse)

        fun selectOrganism(org: String, emoji: String, name: String, depth: String) {
            selectedOrganism = org
            tvSelectedOrganismVisual.text = emoji
            tvOrganismName.text = name
            tvDepthIndicator.text = depth
            Toast.makeText(this, "Diving companion: $name", Toast.LENGTH_SHORT).show()
        }

        whale?.setOnClickListener { selectOrganism("whale", "🐋", "Blue Whale Leviathan", "Depth: 120m — Abyssal Zone") }
        dolphin?.setOnClickListener { selectOrganism("dolphin", "🐬", "Oceanic Dolphin", "Depth: 40m — Sunlight Zone") }
        jelly?.setOnClickListener { selectOrganism("jelly", "🪼", "Bioluminescent Jellyfish", "Depth: 90m — Midnight Trench") }
        turtle?.setOnClickListener { selectOrganism("turtle", "🐢", "Azure Sea Turtle", "Depth: 55m — Twilight Zone") }
        clown?.setOnClickListener { selectOrganism("clownfish", "🐠", "Coral Clownfish", "Depth: 25m — Shallow Coral Reef") }
        seahorse?.setOnClickListener { selectOrganism("seahorse", "🪸", "Golden Seahorse", "Depth: 15m — Coastal Lagoon") }
    }

    private fun setupDurationChips() {
        val c15 = findViewById<TextView>(R.id.chip15m)
        val c25 = findViewById<TextView>(R.id.chip25m)
        val c45 = findViewById<TextView>(R.id.chip45m)
        val c60 = findViewById<TextView>(R.id.chip60m)
        val c90 = findViewById<TextView>(R.id.chip90m)
        val c120 = findViewById<TextView>(R.id.chip120m)
        chips = listOf(c15, c25, c45, c60, c90, c120)

        fun selectChip(chip: TextView, mins: Int) {
            selectedFocusMinutes = mins
            chips.forEach {
                it.setTextColor(0xFF38BDF8.toInt())
                it.setBackgroundResource(R.drawable.bg_pill)
            }
            chip.setTextColor(0xFFFFFFFF.toInt())
            tvTimerCountdown.text = String.format("%02d:00", mins)
        }

        c15?.setOnClickListener { selectChip(c15, 15) }
        c25?.setOnClickListener { selectChip(c25, 25) }
        c45?.setOnClickListener { selectChip(c45, 45) }
        c60?.setOnClickListener { selectChip(c60, 60) }
        c90?.setOnClickListener { selectChip(c90, 90) }
        c120?.setOnClickListener { selectChip(c120, 120) }
    }

    private fun startDiveSession(minutes: Int) {
        sessionManager.startSession(minutes, 0)
        vitalityPoints += 20
        tvVitalityBadge.text = "🫧 $vitalityPoints VP"

        val serviceIntent = Intent(this, SessionTimerService::class.java)
        startService(serviceIntent)

        updateTimerStateUI()
        Toast.makeText(this, "🌊 Dive session begun! Apps strictly locked.", Toast.LENGTH_SHORT).show()
    }

    private fun updateTimerStateUI() {
        diveTimer?.cancel()
        if (sessionManager.isSessionActive()) {
            btnStartDive.text = "🛑 EMERGENCY SURFACE (MATH CHALLENGE)"
            btnStartDive.setBackgroundColor(0xFFDC2626.toInt())

            val remainingMs = sessionManager.getRemainingTimeMs()
            diveTimer = object : CountDownTimer(remainingMs, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    val m = millisUntilFinished / 60000
                    val s = (millisUntilFinished % 60000) / 1000
                    tvTimerCountdown.text = String.format("%02d:%02d", m, s)
                }

                override fun onFinish() {
                    sessionManager.endSession(completed = true)
                    updateTimerStateUI()
                    refreshStatsUI()
                    refreshLogsUI()
                    Toast.makeText(this@MainActivity, "🎉 Dive completed! Ocean Sanctuary flourished!", Toast.LENGTH_LONG).show()
                }
            }.start()
        } else {
            btnStartDive.text = "🌊 DIVE INTO DEEP FOCUS"
            btnStartDive.setBackgroundColor(0xFF06B6D4.toInt())
            tvTimerCountdown.text = String.format("%02d:00", selectedFocusMinutes)
        }
    }

    private fun setupAquariumAndDecorators() {
        val btnFeed = findViewById<Button>(R.id.btnFeedCreatures)
        btnFeed?.setOnClickListener {
            vitalityPoints += 10
            tvVitalityBadge.text = "🫧 $vitalityPoints VP"

            val floatAnim = AnimationUtils.loadAnimation(this, R.anim.ocean_float)
            findViewById<View>(R.id.bubble1)?.startAnimation(floatAnim)
            findViewById<View>(R.id.bubble2)?.startAnimation(floatAnim)

            Toast.makeText(this, "🫧 Marine life fed! +10 Vitality Points", Toast.LENGTH_SHORT).show()
        }

        // Decorators interactive toggle & purchase
        val pGalleon = findViewById<View>(R.id.cardDecoGalleon)
        val pAtlantis = findViewById<View>(R.id.cardDecoAtlantis)
        val pPearl = findViewById<View>(R.id.cardDecoPearl)
        val pAnemone = findViewById<View>(R.id.cardDecoAnemone)
        val pVent = findViewById<View>(R.id.cardDecoVent)

        val tvPearl = findViewById<TextView>(R.id.tvDecoStatusPearl)
        val tvAnemone = findViewById<TextView>(R.id.tvDecoStatusAnemone)
        val tvVent = findViewById<TextView>(R.id.tvDecoStatusVent)

        pGalleon?.setOnClickListener { Toast.makeText(this, "🏴‍☠️ Sunken Galleon Active: Emits gold bubbles", Toast.LENGTH_SHORT).show() }
        pAtlantis?.setOnClickListener { Toast.makeText(this, "🏛️ Atlantean Pillars Active: Enhances discipline aura", Toast.LENGTH_SHORT).show() }

        pPearl?.setOnClickListener {
            if (!unlockedPearl) {
                if (vitalityPoints >= 180) {
                    vitalityPoints -= 180
                    unlockedPearl = true
                    tvVitalityBadge.text = "🫧 $vitalityPoints VP"
                    tvPearl.text = "ACTIVE"
                    tvPearl.setTextColor(0xFF00F5D4.toInt())
                    Toast.makeText(this, "🦪 Luminescent Pearl Clam Unlocked!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Need 180 VP to unlock Luminescent Pearl Clam", Toast.LENGTH_SHORT).show()
                }
            }
        }

        pAnemone?.setOnClickListener {
            if (!unlockedAnemone) {
                if (vitalityPoints >= 240) {
                    vitalityPoints -= 240
                    unlockedAnemone = true
                    tvVitalityBadge.text = "🫧 $vitalityPoints VP"
                    tvAnemone.text = "ACTIVE"
                    tvAnemone.setTextColor(0xFF00F5D4.toInt())
                    Toast.makeText(this, "🌸 Electric Pink Anemone Field Unlocked!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Need 240 VP to unlock Pink Anemone", Toast.LENGTH_SHORT).show()
                }
            }
        }

        pVent?.setOnClickListener {
            if (!unlockedVent) {
                if (vitalityPoints >= 350) {
                    vitalityPoints -= 350
                    unlockedVent = true
                    tvVitalityBadge.text = "🫧 $vitalityPoints VP"
                    tvVent.text = "ACTIVE"
                    tvVent.setTextColor(0xFF00F5D4.toInt())
                    Toast.makeText(this, "🏮 Abyssal Hydrothermal Vent Unlocked!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Need 350 VP to unlock Hydrothermal Vent", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startAquariumAnimations() {
        try {
            val floatAnim = AnimationUtils.loadAnimation(this, R.anim.ocean_float)
            val swayAnim = AnimationUtils.loadAnimation(this, R.anim.wave_sway)
            val pulseAnim = AnimationUtils.loadAnimation(this, R.anim.bioluminescent_pulse)

            findViewById<View>(R.id.marineWhale)?.startAnimation(floatAnim)
            findViewById<View>(R.id.marineDolphin)?.startAnimation(floatAnim)
            findViewById<View>(R.id.marineTurtle)?.startAnimation(swayAnim)
            findViewById<View>(R.id.marineJellyfish)?.startAnimation(pulseAnim)
            findViewById<View>(R.id.marineClownfish)?.startAnimation(swayAnim)
            findViewById<View>(R.id.bubble1)?.startAnimation(floatAnim)
            findViewById<View>(R.id.bubble2)?.startAnimation(floatAnim)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupHabits() {
        val cb1 = findViewById<CheckBox>(R.id.cbHabit1)
        val cb2 = findViewById<CheckBox>(R.id.cbHabit2)
        val cb3 = findViewById<CheckBox>(R.id.cbHabit3)
        val cb4 = findViewById<CheckBox>(R.id.cbHabit4)

        fun updateHabitScore() {
            var checked = 0
            if (cb1?.isChecked == true) checked++
            if (cb2?.isChecked == true) checked++
            if (cb3?.isChecked == true) checked++
            if (cb4?.isChecked == true) checked++
            val pct = (checked * 100) / 4
            tvHabitScore.text = "$pct% Success"
        }

        cb1?.setOnCheckedChangeListener { _, _ -> updateHabitScore() }
        cb2?.setOnCheckedChangeListener { _, _ -> updateHabitScore() }
        cb3?.setOnCheckedChangeListener { _, _ -> updateHabitScore() }
        cb4?.setOnCheckedChangeListener { _, _ -> updateHabitScore() }
    }

    private fun setupAppsList() {
        rvApps.layoutManager = LinearLayoutManager(this)
        appAdapter = AppListAdapter { pkg, isBlocked ->
            val set = sessionManager.blockedPackages.toMutableSet()
            if (isBlocked) set.add(pkg) else set.remove(pkg)
            sessionManager.blockedPackages = set
            updateAppsBadge()
        }
        rvApps.adapter = appAdapter

        btnSelectAll.setOnClickListener {
            val allPkgs = allAppsList.map { it.packageName }.toSet()
            sessionManager.blockedPackages = allPkgs
            appAdapter.setData(filteredAppsList, allPkgs)
            updateAppsBadge()
        }

        btnClearAll.setOnClickListener {
            sessionManager.blockedPackages = emptySet()
            appAdapter.setData(filteredAppsList, emptySet())
            updateAppsBadge()
        }

        // Quick Presets
        findViewById<View>(R.id.presetSocialMedia)?.setOnClickListener {
            val keywords = listOf("insta", "face", "tik", "snap", "twit", "x", "reddit", "youtube", "social")
            val matching = allAppsList.filter { item ->
                keywords.any { k -> item.appName.contains(k, ignoreCase = true) || item.packageName.contains(k, ignoreCase = true) }
            }.map { it.packageName }.toSet()
            sessionManager.blockedPackages = matching
            appAdapter.setData(filteredAppsList, matching)
            updateAppsBadge()
            Toast.makeText(this, "📱 Locked ${matching.size} Social Media Apps", Toast.LENGTH_SHORT).show()
        }

        findViewById<View>(R.id.presetGaming)?.setOnClickListener {
            val keywords = listOf("game", "play", "netflix", "prime", "twitch", "disney", "steam", "roblox")
            val matching = allAppsList.filter { item ->
                keywords.any { k -> item.appName.contains(k, ignoreCase = true) || item.packageName.contains(k, ignoreCase = true) }
            }.map { it.packageName }.toSet()
            sessionManager.blockedPackages = matching
            appAdapter.setData(filteredAppsList, matching)
            updateAppsBadge()
            Toast.makeText(this, "🎮 Locked ${matching.size} Entertainment & Game Apps", Toast.LENGTH_SHORT).show()
        }

        findViewById<View>(R.id.presetMaxLock)?.setOnClickListener {
            val allPkgs = allAppsList.map { it.packageName }.toSet()
            sessionManager.blockedPackages = allPkgs
            appAdapter.setData(filteredAppsList, allPkgs)
            updateAppsBadge()
            Toast.makeText(this, "🚨 Maximum Lockdown: All ${allPkgs.size} apps locked", Toast.LENGTH_SHORT).show()
        }

        etSearchApps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterApps(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun loadAllApps() {
        if (allAppsList.isNotEmpty()) return
        thread {
            val pm = packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val list = mutableListOf<AppInfoItem>()
            for (app in packages) {
                if (app.packageName == packageName) continue
                val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                if (!isSystem) {
                    val name = pm.getApplicationLabel(app).toString()
                    val icon = pm.getApplicationIcon(app)
                    list.add(AppInfoItem(name, app.packageName, icon))
                }
            }
            list.sortBy { it.appName.lowercase() }
            runOnUiThread {
                allAppsList = list
                filteredAppsList = list
                appAdapter.setData(filteredAppsList, sessionManager.blockedPackages)
                updateAppsBadge()
            }
        }
    }

    private fun filterApps(query: String) {
        filteredAppsList = if (query.isBlank()) {
            allAppsList
        } else {
            allAppsList.filter {
                it.appName.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
            }
        }
        appAdapter.setData(filteredAppsList, sessionManager.blockedPackages)
    }

    private fun updateAppsBadge() {
        val count = sessionManager.blockedPackages.size
        tvAppsCountBadge.text = "$count of ${allAppsList.size} locked"
        btnSubTabBlocklist.text = "🛡️ Blocklist ($count)"
    }

    private fun setupStats() {
        refreshStatsUI()
    }

    private fun refreshStatsUI() {
        val score = sessionManager.getDisciplineScore()
        tvDisciplineScore.text = "$score%"

        val totalMins = sessionManager.getTotalFocusMinutes()
        val hrs = totalMins / 60
        val mins = totalMins % 60
        tvTotalFocusHours.text = if (hrs > 0) "${hrs}h ${mins}m" else "${mins}m"
        tvSessionsCompleted.text = "${sessionManager.getCompletedSessionsCount()} Dives"

        layoutWeeklyGraph.removeAllViews()
        val weekly = sessionManager.getWeeklyStats()
        val maxMins = maxOf(60, weekly.maxOfOrNull { it.second } ?: 60)

        for ((day, focusMins) in weekly) {
            val barLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            }

            val bar = View(this).apply {
                val heightPx = ((focusMins.toFloat() / maxMins.toFloat()) * 120 * resources.displayMetrics.density).toInt()
                layoutParams = LinearLayout.LayoutParams(
                    (18 * resources.displayMetrics.density).toInt(),
                    maxOf((8 * resources.displayMetrics.density).toInt(), heightPx)
                )
                setBackgroundColor(0xFF00F5D4.toInt())
            }

            val tvDay = TextView(this).apply {
                text = day
                setTextColor(0xFF94A3B8.toInt())
                textSize = 10f
                gravity = android.view.Gravity.CENTER
                setPadding(0, (4 * resources.displayMetrics.density).toInt(), 0, 0)
            }

            barLayout.addView(bar)
            barLayout.addView(tvDay)
            layoutWeeklyGraph.addView(barLayout)
        }
    }

    private fun setupLogs() {
        rvLogs.layoutManager = LinearLayoutManager(this)
        btnClearLogs.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Are you sure you want to clear your focus dive history?")
                .setPositiveButton("Clear") { _, _ ->
                    sessionManager.clearLogs()
                    refreshLogsUI()
                    refreshStatsUI()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        refreshLogsUI()
    }

    private fun refreshLogsUI() {
        val logs = sessionManager.getSessionLogs()
        if (logs.isEmpty()) {
            tvEmptyLogs.visibility = View.VISIBLE
            rvLogs.visibility = View.GONE
        } else {
            tvEmptyLogs.visibility = View.GONE
            rvLogs.visibility = View.VISIBLE
            rvLogs.adapter = LogsAdapter(logs)
        }
    }

    private fun startAmbientSound() {
        stopAmbientSound()
        audioRunning = true
        thread {
            try {
                val sampleRate = 22050
                val buffSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffSize)
                    .build()
                synthTrack = track
                track.play()

                val buffer = ShortArray(buffSize)
                var angle = 0.0
                while (audioRunning) {
                    for (i in buffer.indices) {
                        angle += 2.0 * Math.PI * 180.0 / sampleRate
                        val wave = (sin(angle) * 3000.0).toInt()
                        val noise = ((Math.random() - 0.5) * 1200.0).toInt()
                        buffer[i] = (wave + noise).toShort()
                    }
                    track.write(buffer, 0, buffer.size)
                }
                track.stop()
                track.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun stopAmbientSound() {
        audioRunning = false
        try {
            synthTrack?.stop()
            synthTrack?.release()
        } catch (e: Exception) {}
        synthTrack = null
    }

    private fun checkPermissions() {
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val service = packageName + "/" + FocusAccessibilityService::class.java.canonicalName
        if (!enabledServices.contains(service)) {
            AlertDialog.Builder(this)
                .setTitle("🌊 FocusLock Accessibility Required")
                .setMessage("FocusLock needs Accessibility to instantly lock distracting apps during focus sessions.")
                .setPositiveButton("Enable in Settings") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }
}

class AppListAdapter(
    private val onToggle: (String, Boolean) -> Unit
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {
    private var items = listOf<AppInfoItem>()
    private var blockedSet = setOf<String>()

    fun setData(newItems: List<AppInfoItem>, blocked: Set<String>) {
        items = newItems
        blockedSet = blocked
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_block, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.appName
        holder.tvPackage.text = item.packageName
        if (item.icon != null) {
            holder.ivIcon.setImageDrawable(item.icon)
        } else {
            holder.ivIcon.setImageResource(android.R.drawable.sym_def_app_icon)
        }

        val isBlocked = blockedSet.contains(item.packageName)
        holder.cbBlocked.isChecked = isBlocked
        holder.itemView.setOnClickListener {
            val newState = !holder.cbBlocked.isChecked
            holder.cbBlocked.isChecked = newState
            onToggle(item.packageName, newState)
        }
        holder.cbBlocked.setOnClickListener {
            onToggle(item.packageName, holder.cbBlocked.isChecked)
        }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        val tvName: TextView = itemView.findViewById(R.id.tvAppName)
        val tvPackage: TextView = itemView.findViewById(R.id.tvAppPackage)
        val cbBlocked: CheckBox = itemView.findViewById(R.id.cbBlocked)
    }
}

class LogsAdapter(private val logs: List<SessionLog>) : RecyclerView.Adapter<LogsAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_session_log, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val log = logs[position]
        val sdf = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault())
        holder.tvDate.text = sdf.format(Date(log.timestamp))
        holder.tvDuration.text = "${log.completedMinutes}m focused (Planned: ${log.plannedMinutes}m)"
        holder.tvAppsLocked.text = "${log.blockedAppsCount} apps locked"

        when (log.status) {
            "COMPLETED" -> {
                holder.tvStatusBadge.text = "COMPLETED"
                holder.tvStatusBadge.setBackgroundColor(0xFF0C4A6E.toInt())
                holder.tvStatusBadge.setTextColor(0xFF00F5D4.toInt())
            }
            "EMERGENCY_UNLOCKED" -> {
                holder.tvStatusBadge.text = "EMERGENCY PASS"
                holder.tvStatusBadge.setBackgroundColor(0xFF7F1D1D.toInt())
                holder.tvStatusBadge.setTextColor(0xFFFCA5A5.toInt())
            }
            else -> {
                holder.tvStatusBadge.text = "ABANDONED"
                holder.tvStatusBadge.setBackgroundColor(0xFF1E293B.toInt())
                holder.tvStatusBadge.setTextColor(0xFF94A3B8.toInt())
            }
        }
    }

    override fun getItemCount(): Int = logs.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDate: TextView = itemView.findViewById(R.id.tvLogDate)
        val tvDuration: TextView = itemView.findViewById(R.id.tvLogDuration)
        val tvAppsLocked: TextView = itemView.findViewById(R.id.tvLogAppsLocked)
        val tvStatusBadge: TextView = itemView.findViewById(R.id.tvLogStatusBadge)
    }
}