package com.vidhya.focuslock

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MathPuzzleActivity : Activity() {
    private lateinit var sessionManager: SessionManager
    private var correctAnswer = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)
        sessionManager = SessionManager(applicationContext)

        val tvQuestion = findViewById<TextView>(R.id.tvMathQuestion)
        val etAnswer = findViewById<EditText>(R.id.etMathAnswer)
        val btnSubmit = findViewById<Button>(R.id.btnSubmitAnswer)

        val num1 = Random.nextInt(18, 55)
        val num2 = Random.nextInt(14, 48)
        correctAnswer = num1 * num2
        tvQuestion.text = "Solve to Surface: $num1 × $num2 = ?"

        btnSubmit.setOnClickListener {
            val ans = etAnswer.text.toString().trim().toIntOrNull()
            if (ans == correctAnswer) {
                sessionManager.grantEmergencyPass(2)
                Toast.makeText(this, "⚠️ Emergency 2-Minute Pass Granted! Surface active.", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this, "❌ Incorrect answer! Deep ocean lock remains active.", Toast.LENGTH_SHORT).show()
                etAnswer.text.clear()
            }
        }
    }
}