package com.vidhya.focuslock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView

class BlockActivity : Activity() {
    private lateinit var sessionManager: SessionManager
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block)
        sessionManager = SessionManager(applicationContext)

        val tvTime = findViewById<TextView>(R.id.tvBlockTimeRemaining)
        val btnBack = findViewById<Button>(R.id.btnBackToSanctuary)
        val btnEmergency = findViewById<Button>(R.id.btnEmergencyUnlock)

        btnBack.setOnClickListener {
            val home = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(home)
            finish()
        }

        btnEmergency.setOnClickListener {
            sessionManager.recordDisableAttempt()
            startActivity(Intent(this, MathPuzzleActivity::class.java))
            finish()
        }

        val remainingMs = sessionManager.getRemainingTimeMs()
        timer = object : CountDownTimer(maxOf(1000L, remainingMs), 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val mins = millisUntilFinished / 60000
                val secs = (millisUntilFinished % 60000) / 1000
                tvTime.text = String.format("%02d:%02d", mins, secs)
            }

            override fun onFinish() {
                finish()
            }
        }.start()
    }

    override fun onBackPressed() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}